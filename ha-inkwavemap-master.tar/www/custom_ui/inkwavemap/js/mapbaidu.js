function MapBaidu() {
}

MapBaidu.prototype = {
    
}